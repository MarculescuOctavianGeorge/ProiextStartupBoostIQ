﻿using System;
namespace PAVOC.DataModel.Repository.Interface
{
    public interface IRepository
    {
    }
}
