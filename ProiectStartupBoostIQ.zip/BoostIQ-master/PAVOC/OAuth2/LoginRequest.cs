﻿using System;
namespace PAVOC.OAuth2
{
    public class LoginRequest
    {
        public string username { get; set; }
        public string password { get; set; }
    }
}
