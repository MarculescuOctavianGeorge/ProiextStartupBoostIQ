﻿using System;
namespace PAVOC.Common.DTO
{
    public class ScoreDTO
    {
        public int position { get; set; }
        public string username { get; set; }
        public int score{ get; set; }
    }
}
