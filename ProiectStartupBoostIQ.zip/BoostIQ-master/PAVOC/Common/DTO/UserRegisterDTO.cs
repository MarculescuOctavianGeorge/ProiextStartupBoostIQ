﻿using System;
namespace PAVOC.Common.DTO
{
    public class UserRegisterDTO
    {
        public string username { get; set; }
        public string password { get; set; }
        public string email { get; set; }
    }
}
